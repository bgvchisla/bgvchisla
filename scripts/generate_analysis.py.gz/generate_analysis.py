#!/usr/bin/env python3
"""Weekly evidence-led analysis pipeline for Bulgaria in Numbers."""
import argparse, datetime as dt, html, json, os, re, sys, urllib.request, urllib.error
from pathlib import Path
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parents[1]; TZ=ZoneInfo('Europe/Sofia'); BASE='https://bgvchisla.com'
P={k:R/v for k,v in {'news':'news.json','fiscal':'official_fiscal.json','economy':'economy.json','bnb':'official_bnb.json','nssi':'official_nssi.json','business':'official_business_climate.json','cfg':'analysis/config.json','usage':'analysis/monthly_usage.json','articles':'analizi/articles.json','archive':'analizi/index.html','sitemap':'sitemap.xml'}.items()}
DASH=str.maketrans({'—':'-','–':'-','―':'-','‒':'-','―':'-'})
BG=('иконом','бюджет','дълг','бвп','инфлац','цени','кредит','депозит','лихв','бан','доход','зает','енерг','бизнес','износ','внос','инвести','пазар','разход','приход')
WORLD=('econom','inflation','interest rate','central bank','ecb','fed','gdp','trade','tariff','budget','debt','bond','market','energy','oil','gas','investment','imf','oecd','world bank','финанс','лихв','иконом','пазар','енерг','газ','петрол','облигац','търгов')
SCHEMA={'type':'object','additionalProperties':False,'properties':{
 'title':{'type':'string'},'dek':{'type':'string'},'summary':{'type':'string'},
 'sections':{'type':'array','items':{'type':'object','additionalProperties':False,'properties':{
  'heading':{'type':'string'},'paragraphs':{'type':'array','items':{'type':'object','additionalProperties':False,'properties':{
   'text':{'type':'string'},'source_ids':{'type':'array','items':{'type':'string'}}},'required':['text','source_ids']}}},'required':['heading','paragraphs']}},
 'key_points':{'type':'array','items':{'type':'object','additionalProperties':False,'properties':{'text':{'type':'string'},'source_ids':{'type':'array','items':{'type':'string'}}},'required':['text','source_ids']}},
 'conclusion':{'type':'string'},'methodology_note':{'type':'string'},'used_source_ids':{'type':'array','items':{'type':'string'}},'chart_series_id':{'type':'string'}},
 'required':['title','dek','summary','sections','key_points','conclusion','methodology_note','used_source_ids','chart_series_id']}
def read(key,default=None):
 p=P[key]
 if not p.exists():
  if default is not None:return default
  raise RuntimeError('Missing file: '+str(p.relative_to(R)))
 try:return json.loads(p.read_text(encoding='utf-8'))
 except Exception as e:raise RuntimeError('Invalid JSON '+str(p)+': '+str(e))
def write(key,obj):
 p=P[key];p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def clean(s):return re.sub(r'\s+',' ',str(s).translate(DASH)).strip()
def date(s):
 try:
  x=dt.datetime.fromisoformat(str(s).replace('Z','+00:00'));return (x if x.tzinfo else x.replace(tzinfo=dt.timezone.utc)).astimezone(dt.timezone.utc)
 except Exception:return None
def get_evidence(lane):
 news=read('news');health=news.get('feed_status',{})
 if health.get('ok',0)<max(8,(health.get('total',0)+1)//2):raise RuntimeError('News feed health below threshold')
 old=read('articles',[]);used={u for a in old[-12:] for u in a.get('source_urls',[])}
 sec='bulgaria' if lane=='bulgaria' else 'europe';terms=BG if lane=='bulgaria' else WORLD;now=dt.datetime.now(dt.timezone.utc);rank=[]
 for x in news.get('items',[]):
  d=date(x.get('published'));url=x.get('url','');title=str(x.get('title',''));body=(title+' '+str(x.get('summary',''))).lower()
  if x.get('section')!=sec or not url.startswith('https://') or url in used or not d or (now-d).days>10 or d>now+dt.timedelta(hours=3):continue
  score=sum(2 if t in title.lower() else 1 for t in terms if t in body)
  if score:rank.append((score,d,x))
 rank.sort(key=lambda v:(v[0],v[1]),reverse=True);items=[];outlets=set()
 for _,d,x in rank:
  outlet=clean(x.get('source','Източник'))
  if outlet in outlets and len(items)>=3:continue
  items.append({'source_id':f'N{len(items)+1:02d}','publisher':outlet,'title':clean(x.get('title','')),'url':x['url'],'published':d.isoformat(),'summary':clean(x.get('summary',''))[:650]});outlets.add(outlet)
  if len(items)>=8:break
 if len(items)<4 or len(outlets)<3:raise RuntimeError('Need 4 recent relevant news items from at least 3 publishers')
 sources=[];datasets=[];charts=[]
 if lane=='bulgaria':
  defs=[('D01','fiscal','Месечни фискални данни'),('D02','economy','Макроикономически показатели и Евростат'),('D03','bnb','Кредитна статистика на БНБ'),('D04','nssi','Статистика на НОИ'),('D05','business','Бизнес климат на НСИ')]
  for sid,key,label in defs:
   data=read(key);url=data.get('source_url','') or ('https://ec.europa.eu/eurostat/web/main/data/database' if key=='economy' else '')
   if not url.startswith('https://'):raise RuntimeError('Missing official source URL: '+key)
   publisher=data.get('source') or ('Евростат' if key=='economy' else '')
   sources.append({'source_id':sid,'publisher':clean(publisher),'title':label,'url':url,'updated_at':data.get('updated_at','')})
   if key in ('fiscal','bnb'):
    facts=[{'id':x.get('id'),'label':clean(x.get('title') or x.get('label') or x.get('id')),'unit':x.get('unit'),'points':x.get('points',[])[-6:]} for x in (data.get('series',[]) if isinstance(data.get('series',[]),list) else [dict(v,id=k) for k,v in data.get('series',{}).items()])[:8] if x.get('points')]
   elif key=='economy':
    keep={'gdp_real_growth','gdp_per_capita_current_eur','employment_rate_20_64','unemployment_rate_15_74','gdp_pps_index','exports_goods_mio_eur','imports_goods_mio_eur','population_total'}
    facts=[{'id':x.get('id'),'label':x.get('label',x.get('id')),'points':x.get('points',[])[-8:]} for x in data.get('series',[]) if x.get('id') in keep]
    for x in data.get('series',[]):
     if x.get('id') in keep and len(x.get('points',[]))>=4:charts.append({'id':x['id'],'label':x.get('label',x['id']),'unit':x.get('unit',''),'points':x['points'][-10:]})
   elif key=='nssi':facts=data.get('metrics',{})
   else:facts={'reference_date':data.get('reference_date'),'values':data.get('values',{})}
   datasets.append({'source_id':sid,'period':data.get('latest_period') or data.get('reference_date'),'methodology':clean(data.get('methodology',''))[:700],'facts':facts})
 return {'lane':lane,'generated_at':dt.datetime.now(TZ).isoformat(),'feed_health':health,'sources':sources+items,'datasets':datasets,'chart_candidates':charts}
def api(prompt,cfg):
 key=os.getenv('OPENAI_API_KEY','').strip()
 if not key:raise RuntimeError('OPENAI_API_KEY secret missing; no API call made')
 body={'model':cfg['model'],'instructions':"Ти си старши икономически редактор на БЪЛГАРИЯ В ЧИСЛА. Напиши задълбочен и точен анализ на български. Работи само с предоставените доказателства. Не измисляй числа, дати, цитати или URL. Разграничавай факт, интерпретация и сценарий. Всеки абзац и ключов извод трябва да цитира source_ids от пакета. Не давай индивидуални инвестиционни съвети. НИКОГА не използвай дълго тире, средно тире, figure dash или horizontal bar. Използвай само обикновен дефис '-' или друга пунктуация.",'input':prompt,'reasoning':{'effort':'low'},'max_output_tokens':cfg['max_output_tokens'],'text':{'format':{'type':'json_schema','name':'bgvchisla_analysis','strict':True,'schema':SCHEMA}}}
 req=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(body,ensure_ascii=False).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=180) as r:res=json.loads(r.read(2000000).decode())
 except urllib.error.HTTPError as e:raise RuntimeError('OpenAI API HTTP '+str(e.code)+': '+e.read(1500).decode('utf-8','replace'))
 except urllib.error.URLError as e:raise RuntimeError('OpenAI API connection failed: '+str(e))
 if res.get('status')!='completed':raise RuntimeError('Incomplete API response')
 txt='\n'.join(c.get('text','') for x in res.get('output',[]) if x.get('type')=='message' for c in x.get('content',[]) if c.get('type')=='output_text')
 if not txt:raise RuntimeError('Empty model output')
 a=json.loads(txt);u=res.get('usage',{});i=int(u.get('input_tokens',0));o=int(u.get('output_tokens',0))
 if not i or not o:raise RuntimeError('Missing API usage metadata')
 return a,u,round(i*cfg['input_usd_per_million']/1e6+o*cfg['output_usd_per_million']/1e6,6)
def record_usage(u,cost,cfg):
 month=dt.datetime.now(TZ).strftime('%Y-%m');v=read('usage',{'month':month,'spent_usd':0.0,'calls':0,'history':[]})
 if v.get('month')!=month:v={'month':month,'spent_usd':0.0,'calls':0,'history':v.get('history',[])[-12:]}
 v['spent_usd']=round(v.get('spent_usd',0)+cost,6);v['calls']+=1;v.setdefault('history',[]).append({'date':dt.datetime.now(TZ).isoformat(),'cost_usd':cost,'input_tokens':u['input_tokens'],'output_tokens':u['output_tokens']});v['history']=v['history'][-60:];write('usage',v)
 if v['spent_usd']>cfg['monthly_budget_usd']:raise RuntimeError('Monthly internal API budget exceeded; publication blocked')
def validate(a,pack,cfg):
 src={x['source_id']:x for x in pack['sources']};used=a.get('used_source_ids',[])
 if len(set(used))<cfg['minimum_sources'] or any(x not in src for x in used):raise RuntimeError('Source validation failed')
 if len(a.get('sections',[]))<cfg['minimum_sections']:raise RuntimeError('Too few sections')
 paras=[];cited=set()
 for s in a['sections']:
  if not s.get('heading') or len(s.get('paragraphs',[]))<2:raise RuntimeError('Each section needs heading and 2 paragraphs')
  for p in s['paragraphs']:
   if len(p.get('text','').split())<24 or not p.get('source_ids') or any(x not in src for x in p['source_ids']):raise RuntimeError('Paragraph evidence validation failed')
   paras.append(p['text']);cited.update(p['source_ids'])
 for p in a['key_points']:
  if not p.get('source_ids') or any(x not in src for x in p['source_ids']):raise RuntimeError('Key point evidence validation failed')
  cited.update(p['source_ids'])
 if set(used)!=cited:raise RuntimeError('Every cited source must appear in the source list, and every listed source must be cited')
 words=len(re.findall(r'[A-Za-zА-Яа-я0-9]+',' '.join(paras)))
 if not cfg['minimum_words']<=words<=cfg['maximum_words']:raise RuntimeError('Word count out of range: '+str(words))
 chart_id=a.get('chart_series_id','');chart={x['id']:x for x in pack['chart_candidates']}
 if chart_id and chart_id not in chart:raise RuntimeError('Chart series is not in the evidence pack')
 for k in ('title','dek','summary','conclusion','methodology_note'):
  if not a.get(k):raise RuntimeError('Missing field: '+k)
 def tidy(x):
  if isinstance(x,str):return clean(x)
  if isinstance(x,list):return [tidy(y) for y in x]
  if isinstance(x,dict):return {k:tidy(v) for k,v in x.items()}
  return x
 a=tidy(a);a['_src']=src;a['_chart']=chart.get(chart_id);a['_words']=words
 return a
def cite(ids):return ' '+' '.join(f'<a href="#source-{html.escape(x)}">[{html.escape(x)}]</a>' for x in ids)
def chart_html(c):
 if not c:return ''
 pts=[]
 for x in c.get('points',[]):
  try:pts.append((str(x.get('year') or x.get('period','')),float(x['value'])))
  except Exception:pass
 pts=pts[-9:]
 if len(pts)<4:return ''
 lo=min(v for _,v in pts);hi=max(v for _,v in pts) or lo+1;hi=hi if hi!=lo else lo+1
 xy=[(42+i*620/(len(pts)-1),12+(hi-v)/(hi-lo)*140) for i,(_,v) in enumerate(pts)]
 path=' '.join(('M' if i==0 else 'L')+f'{x:.1f},{y:.1f}' for i,(x,y) in enumerate(xy));dots=''.join(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4"/>' for x,y in xy)
 labs=''.join(f'<text x="{xy[i][0]:.1f}" y="185">{html.escape(pts[i][0])}</text>' for i in sorted({0,len(pts)//2,len(pts)-1}))
 return f'<figure><b>{html.escape(c["label"])}</b><svg viewBox="0 0 680 200"><path d="{path}"/>{dots}{labs}</svg><small>Източник: Евростат / официален набор</small></figure>'
def render(a,lane,name,date_label):
 src=a['_src'];sections=[]
 for s in a['sections']:sections.append('<section><h2>'+html.escape(s['heading'])+'</h2>'+''.join('<p>'+html.escape(p['text'])+cite(p['source_ids'])+'</p>' for p in s['paragraphs'])+'</section>')
 points=''.join('<li>'+html.escape(p['text'])+cite(p['source_ids'])+'</li>' for p in a['key_points'])
 refs=''.join(f'<li id="source-{sid}"><b>{sid}</b> <a href="{html.escape(src[sid]["url"],quote=True)}" target="_blank" rel="noopener">{html.escape(src[sid]["publisher"])}: {html.escape(src[sid]["title"])}</a></li>' for sid in a['used_source_ids'])
 title=html.escape(a['title']);summary=html.escape(a['summary']);category='Българска икономика' if lane=='bulgaria' else 'Световна икономика и финансови пазари'
 schema={'@context':'https://schema.org','@type':'Article','headline':a['title'],'description':a['summary'],'datePublished':dt.datetime.now(TZ).isoformat(),'inLanguage':'bg-BG','author':{'@type':'Organization','name':'Редакция БЪЛГАРИЯ В ЧИСЛА'}}
 return f'''<!doctype html><html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title} | БЪЛГАРИЯ В ЧИСЛА</title><meta name="description" content="{summary}"><meta name="robots" content="index,follow"><link rel="canonical" href="{BASE}/analizi/{name}"><script type="application/ld+json">{json.dumps(schema,ensure_ascii=False)}</script><style>body{{margin:0;background:#f4f6f8;color:#263445;font:16px/1.7 system-ui}}header{{padding:18px max(18px,calc((100% - 820px)/2));background:#e8eef4;border-bottom:2px solid #bd514b}}a{{color:#315f91}}main{{max-width:820px;margin:30px auto;padding:0 18px 60px}}h1,h2{{color:#24384f}}h1{{font-size:clamp(2rem,5vw,3.1rem);line-height:1.15}}.meta,small{{color:#718096;font-size:.8rem}}.summary,.key,.method,.sources,figure{{background:#fff;padding:18px;border:1px solid #e1e6eb;border-radius:6px;margin:24px 0}}figure svg{{width:100%;height:auto}}figure path{{fill:none;stroke:#315f91;stroke-width:3}}figure circle{{fill:#bd514b}}figure text{{font:12px system-ui;fill:#718096}}footer{{border-top:1px solid #e1e6eb;margin-top:35px;padding-top:18px;color:#718096;font-size:.8rem}}</style></head><body><header><a href="/">БЪЛГАРИЯ В ЧИСЛА / ФАКТИТЕ. БЕЗ ШУМ.</a></header><main><div class="meta">АНАЛИЗИ / {category}</div><h1>{title}</h1><p>{html.escape(a['dek'])}</p><div class="meta">Редакция БЪЛГАРИЯ В ЧИСЛА / {date_label} / {a['_words']} думи</div><div class="summary">{summary}</div><div class="key"><h2>Основни изводи</h2><ul>{points}</ul></div><article>{chart_html(a['_chart'])}{''.join(sections)}</article><div class="method"><h2>Методология и ограничения</h2><p>{html.escape(a['methodology_note'])}</p><p>{html.escape(a['conclusion'])}</p></div><div class="sources"><h2>Източници и документи</h2><ol>{refs}</ol></div><footer>Материал на редакцията на БЪЛГАРИЯ В ЧИСЛА. Информационен анализ, не е индивидуален инвестиционен съвет.</footer></main></body></html>'''
def archive_page(items):
 cards=''.join(f'<a class="card" href="{html.escape(x["url"],quote=True)}"><small>{html.escape(x["date_label"])} / {html.escape(x["lane_label"])}</small><h2>{html.escape(x["title"])}</h2><p>{html.escape(x["summary"])}</p><b>Прочети анализа ↗</b></a>' for x in sorted(items,key=lambda y:y.get('date',''),reverse=True))
 body=cards or '<div class="empty"><strong>Първият анализ се подготвя.</strong><p>Два пъти седмично ще публикуваме анализи за България, световните пазари и паричната политика.</p></div>'
 return f'''<!doctype html><html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Анализи | БЪЛГАРИЯ В ЧИСЛА</title><meta name="description" content="Икономиката отвъд заглавията. Анализи за България, световната икономика, финансовите пазари и паричната политика."><link rel="canonical" href="{BASE}/analizi/"><style>body{{margin:0;background:#f4f6f8;color:#263445;font:16px/1.5 system-ui}}header{{background:#e8eef4;border-bottom:2px solid #bd514b;padding:18px max(18px,calc((100% - 1100px)/2))}}header a{{color:#24384f;text-decoration:none;font-weight:850}}main{{max-width:1100px;margin:auto;padding:40px 18px 60px}}h1,h2{{color:#24384f}}h1{{font-size:clamp(2.2rem,5vw,3.7rem)}}.lead{{max-width:720px;color:#607187;margin-bottom:30px}}.grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}}.card,.empty{{display:block;background:#fff;border:1px solid #e1e6eb;border-radius:6px;padding:22px;color:inherit;text-decoration:none}}.card small{{color:#718096}}.card p{{color:#607187}}.card b{{color:#315f91}}@media(max-width:680px){{.grid{{grid-template-columns:1fr}}}}</style></head><body><header><a href="/">БЪЛГАРИЯ В ЧИСЛА / ФАКТИТЕ. БЕЗ ШУМ.</a></header><main><small>РЕДАКЦИОННО НАПРАВЛЕНИЕ</small><h1>Анализи</h1><p class="lead">Икономиката отвъд заглавията. Два задълбочени анализа седмично за България, световната икономика, финансовите пазари, лихвените проценти и паричната политика. Данни, контекст и аргументирани изводи.</p><div class="grid">{body}</div></main></body></html>'''
def main():
 p=argparse.ArgumentParser();p.add_argument('--lane',choices=['bulgaria','world'],required=True);p.add_argument('--dry-run',action='store_true');args=p.parse_args();cfg=read('cfg');pack=get_evidence(args.lane)
 instruction="Напиши самостоятелен задълбочен анализ на български език от 900 до 1400 думи. Избери най-силната тема от доказателствата. Не прави преразказ на заглавия. Покажи какво доказват и какво не доказват данните, контекста, последствията и рисковете. Не добавяй неподкрепени числа. Всеки абзац и всеки основен извод трябва да цитира source_ids. Не измисляй котировки, лихви или доходности. Графика може да се избере само от chart_candidates. Не използвай дълги тирета."
 prompt=json.dumps({'assignment':instruction,'evidence':pack},ensure_ascii=False)
 if len(prompt)>cfg['maximum_prompt_characters']:raise RuntimeError('Prompt size guard reached')
 month=dt.datetime.now(TZ).strftime('%Y-%m');ledger=read('usage',{'month':month,'spent_usd':0,'calls':0,'history':[]});spent=ledger.get('spent_usd',0) if ledger.get('month')==month else 0;calls=ledger.get('calls',0) if ledger.get('month')==month else 0
 estimate=(len(prompt)*cfg['input_usd_per_million']+cfg['max_output_tokens']*cfg['output_usd_per_million'])/1e6
 if spent+estimate>cfg['monthly_budget_usd'] or calls>=cfg['max_api_calls_per_month']:raise RuntimeError('Internal API budget guard reached')
 print(f'lane={args.lane}; sources={len(pack["sources"])}; max_reserved_cost_usd={estimate:.6f}; spent_usd={spent:.6f}')
 if args.dry_run:print('DRY RUN: no API call, no charge, no publication');return
 a,u,cost=api(prompt,cfg);record_usage(u,cost,cfg);a=validate(a,pack,cfg);now=dt.datetime.now(TZ);label=now.strftime('%d.%m.%Y')
 slug=a['title'].lower().translate(str.maketrans({'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ж':'zh','з':'z','и':'i','й':'y','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'h','ц':'ts','ч':'ch','ш':'sh','щ':'sht','ъ':'a','ь':'y','ю':'yu','я':'ya'}));slug=re.sub(r'[^a-z0-9]+','-',slug).strip('-')[:60] or 'analiz';name=f'{now:%Y-%m-%d}-{slug}.html';target=R/'analizi'/name
 if target.exists():raise RuntimeError('Article already exists; refusing overwrite')
 txt=' '.join([a['title'],a['dek'],a['summary'],a['conclusion'],a['methodology_note']]+[x['text'] for s in a['sections'] for x in s['paragraphs']]+[x['text'] for x in a['key_points']])
 if any(x in txt for x in ('—','–','―','‒')):raise RuntimeError('Long dash detected; publication blocked')
 page=render(a,args.lane,name,label)
 if any(x in page for x in ('—','–','―','‒')):raise RuntimeError('Long dash detected in HTML; publication blocked')
 target.parent.mkdir(parents=True,exist_ok=True);target.write_text(page,encoding='utf-8');src=a['_src'];ids=a['used_source_ids']
 items=read('articles',[]);items.append({'title':a['title'],'summary':a['summary'],'date':now.date().isoformat(),'date_label':label,'lane_label':'Българска икономика' if args.lane=='bulgaria' else 'Световна икономика и финансови пазари','url':'/analizi/'+name,'source_urls':[src[x]['url'] for x in ids]});items=sorted(items,key=lambda x:x['date'],reverse=True)[:100];write('articles',items);P['archive'].write_text(archive_page(items),encoding='utf-8')
 sm=P['sitemap'];s=sm.read_text(encoding='utf-8')
 for url in (BASE+'/analizi/',BASE+'/analizi/'+name):
  if url not in s:s=s.replace('</urlset>',f'<url><loc>{url}</loc></url></urlset>')
 sm.write_text(s,encoding='utf-8');print('CREATED '+name+'; words='+str(a['_words'])+'; actual_API_cost_USD='+str(cost))
if __name__=='__main__':
 try:main()
 except Exception as e:print('EDITORIAL PIPELINE STOPPED: '+str(e),file=sys.stderr);raise SystemExit(1)
